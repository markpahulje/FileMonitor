# FileMonitor
Monitors files/directories with optional filters from NotifyIcon in taskbar

Requires TaskScheduler NuGet Package: https://www.nuget.org/packages/TaskScheduler/
